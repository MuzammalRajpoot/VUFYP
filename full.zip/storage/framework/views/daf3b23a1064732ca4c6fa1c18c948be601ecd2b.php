<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Mobiles</h1>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Price</th>
                <th>Images</th>
                <th>Camera</th>
                <th>Description</th>
                <th>Ram</th>
                <th>Memory</th>
                <th>SIM Slots</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            <?php $__currentLoopData = $mobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($mobile->mobileId); ?></td>
                    <td><?php echo e($mobile->mobileName); ?></td>
                    <td><?php echo e($mobile->brandId); ?></td>
                    <td><?php echo e($mobile->price); ?></td>
                    <td><?php echo e($mobile->images); ?></td>
                    <td><?php echo e($mobile->camera); ?></td>
                    <td><?php echo e($mobile->description); ?></td>
                    <td><?php echo e($mobile->ram); ?></td>
                    <td><?php echo e($mobile->memory); ?></td>
                    <td><?php echo e($mobile->sim_slots); ?></td>
                    <td><a href="/admin/mobile/update/<?php echo e($mobile->mobileId); ?>" class="btn btn-success">Update</a></td>

                    <td>
                        <form action="<?php echo e(action('MobileController@destroy', $mobile->mobileId)); ?>" method="post">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>