<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mb-4">
            <h1>Update Brand Name</h1>
        </div>
         <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      </div><br />
                    <?php endif; ?>

                    <?php if(session()->get('success')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>  
                    </div><br />
                    <?php endif; ?>
                    <div class="form form-innline mb-3">
                    <form class="form-inline" action="<?php echo e(action('BrandController@update', $brand->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="form-group mb-2">
                                <div class="input-group">
                                    <label class="input-group-addon font-weight-bold">Brand Name:</label>
                                </div>
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <div class="input-group" >
                                    <input type="text" id="brandName" class="form-control<?php echo e($errors->has('brandName') ? ' is-invalid' : ''); ?>" name="brandName" value="<?php echo $brand->brandName ?>" required autofocus>
                                </div>
                            </div>
                             <button type="submit" class="btn btn-primary mb-2">Update Brand Name</button>
                    </form>
                    </div>
                   

                </div>
    </div>

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\mobileinfo\resources\views/update.blade.php */ ?>