<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
             <form action="<?php echo e(action('MobileController@update',  $mobile->mobileId)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="mobileName">Name</label>
                        <input type="text" class="form-control" required autofocus name="mobileName" placeholder="Mobile Name" value="<?php echo $mobile->mobileName; ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="brandId">Brand</label>
                        <select name="brandId" class="form-control" required>
                            <option selected>Select</option>
                            <?php
                                $selectedBrand = $mobile->brandId;
                            ?>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($selectedBrand); ?> value="<?php echo e($brand->id); ?>"  <?php echo e($selectedBrand == $brand->id ?  'selected="selected"' : ''); ?>><?php echo e($brand->brandName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                 <?php
                     $singleimage=explode(',',$mobile->images);
                     $imgcount = 0;
                     for($i=0;$i<sizeof($singleimage);$i++){
                         $imgcount++;
                     ?>
                     <img src="/images/<?php echo e($singleimage[$i]); ?>" alt="mobile" style="max-width:150px; margin: 0 10px">
                 <?php } ?>

                 <div class="input-group control-group increment mb-2" >
                    <input type="file" name="images[]" class="form-control">
                    <div class="input-group-btn">
                        <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
                    </div>
                </div>
                <div class="clone hide">
                    <div class="control-group input-group mb-2" style="margin-top:10px">
                        <input type="file" name="images[]" class="form-control">
                        <div class="input-group-btn">
                            <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" name="description" rows = "5" cols = "50" name ="description" placeholder="Mobile Description..." required><?php echo $mobile->description; ?> </textarea>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-2">
                        <label for="price">Price (PKR)</label>
                        <input type="number" class="form-control" name="price" placeholder="e.g. 12500" value="<?php echo $mobile->price; ?>" required>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="camera">Camera (MP)</label>
                        <input type="number" class="form-control" name="camera" placeholder="e.g. 13" value="<?php echo $mobile->camera; ?>" required>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="sim_slots">Sim Slots</label>
                        <select name="sim_slots" class="form-control" required>

                            <option selected>Select</option>
                            <?php
                                $selectedSim = $mobile->sim_slots;
                            ?>

                            <option value="1" <?php echo e($selectedSim == 1 ?  'selected="selected"' : ''); ?>>1</option>
                            <option value="2" <?php echo e($selectedSim == 2 ?  'selected="selected"' : ''); ?>>2</option>
                            <option value="3" <?php echo e($selectedSim == 3 ?  'selected="selected"' : ''); ?>>3</option>
                        </select>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="ram">RAM (GB)</label>
                        <input type="number" class="form-control" name="ram" placeholder="e.g. 8" value="<?php echo $mobile->ram; ?>" required>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="memory">ROM (GB)</label>
                        <input type="number" class="form-control" name="memory" placeholder="e.g. 32" value="<?php echo $mobile->memory; ?>" required>
                    </div>
                </div>
                <input type="submit" class="btn btn-primary" value="Add Mobile" name="submit">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><br />
                <?php endif; ?>
                <?php if(session()->get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div><br />
                <?php endif; ?>
            </form>
            <script type="text/javascript">

                $(document).ready(function() {

                    $(".btn-success").click(function(){
                        var html = $(".clone").html();
                        $(".increment").after(html);
                    });

                    $("body").on("click",".btn-danger",function(){
                        $(this).parents(".control-group").remove();
                    });

                });

            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>