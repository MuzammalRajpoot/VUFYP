

<?php $__env->startSection('content'); ?>

      <div id="column-left">
        <!--Category Start -->
        <script type="text/javascript" src="js/jquery.dcjqaccordion.js"></script>
        <!--Category End -->
        <!--Refine Search Start-->
        <div class="box">
          <div class="box-heading">Refine Search</div>
          <div class="box-content">
            <ul class="box-filter">
              <li><span id="filter-group">Price</span>
                <ul>
                  <li>
                    <a href="#">
                      <label for="filter3">$0 - $100 (1)</label>
                    </a>
                  </li>
                  <li>
                      <label for="filter4">$100 - $500 (5)</label>
                  </li>
                  <li>
                      <label for="filter5">$500 - $1000 (1)</label>
                  </li>
                  <li>
                     <label for="filter6">$1000 - $1500 (0)</label>
                  </li>
                </ul>
              </li>
            </ul>
            </div>
        </div>
        <!--Refine Search End-->
        <!--Latest Product Start-->
        <div class="box">
          <div class="box-heading">Latest</div>
          <div class="box-content">
            <div class="box-product">
              <div class="flexslider">
                <?php $__currentLoopData = $latestmobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="slides">
                  <li>
                   <?php $singleimage=explode(',',$mobile->images); ?>
                    <div class="slide-inner">
                      <div class="image" style="width:90px;"><a href="http://localhost:8000/mobile/<?php echo e($mobile->mobileId); ?>"><img src="http://localhost:8000/images/<?php echo e($singleimage[0]); ?>" alt="<?php echo e($mobile->mobileName); ?>" /></a></div>
                      <div class="name"><a href="http://localhost:8000/mobile/<?php echo e($mobile->mobileId); ?>"><?php echo e($mobile->mobileName); ?></a></div>
                      <div class="price"><?php echo e($mobile->price); ?> Rs.</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
        <!--Latest Product End-->
      </div>
      <!--Middle Part Start-->
      <div id="content">
        <!--Breadcrumb Part Start-->
        <div class="breadcrumb"> <a href="/">Home</a></div>
        <!--Breadcrumb Part End-->
        <h1>MobileInfo - VU FYP</h1>
        <div class="product-filter">
          <div class="sort"><b>Sort By:</b>


            <form name="myform" action="<?php echo e(route('brand/filter')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="brand" value="<?php echo e($brand); ?>}">
              <select name="filter" onchange="this.form.submit()">
                <option value="page1">Page 1</option>
                <option value="page2">Page 2</option>
                <option value="page3">Page 3</option>
              </select>
            </form>

            <select>
              <option value="" selected="selected">Default</option>
              <option value="">Name (A - Z)</option>
              <option value="">Name (Z - A)</option>
              <option value="">Price (Low &gt; High)</option>
              <option value="">Price (High &gt; Low)</option>
            </select>
          </div>
        </div>

        <!--Product Grid Start-->
        <div class="product-grid">
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobiles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $singleimage=explode(',',$mobiles->images); ?>
          <div>
            <div class="image thumbnail"><a href="http://localhost:8000/mobile/<?php echo e($mobiles->mobileId); ?>"><img width="200" height="200" src="http://localhost:8000/images/<?php echo e($singleimage[0]); ?>" title="<?php echo e($mobiles->mobileName); ?>" alt="<?php echo e($mobiles->mobileName); ?>" /></a></div>
            <div class="name"><a href="http://localhost:8000/mobile/<?php echo e($mobiles->mobileId); ?>"><?php echo e($mobiles->mobileName); ?></a></div>
            <div class="price"> <span class="price-new"><?php echo e($mobiles->price); ?> Rs.</span> <br />
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--Product Grid End-->
        <div class="clear"></div>
        <!--Pagination Part Start-->
        <div style="display:block;">
         <?php echo e($product->links()); ?> 
       </div>
        <!--Pagination Part End-->
        <style>
          
ul.pagination {
    list-style: none;
    display: inline;
    letter-spacing: 9px;
    font-size: 24px;
}
li.page-item {
    float: left;
    font-size: 24px;
}
li.page-item a{
    float: left;
    font-size: 24px !important;
}


        </style>
      </div>
      <!--Middle Part End-->
      <div class="clear"></div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>