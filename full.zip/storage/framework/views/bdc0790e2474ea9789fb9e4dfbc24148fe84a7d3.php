<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="UTF-8" />
<title>MobileInfo - VU FYP</title>
<link href="image/favicon.png" rel="icon" /> 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="clean modern and elegant corporate look eCommerce html template">
<meta name="author" content="">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="http://localhost:8000/css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="http://localhost:8000/css/slideshow.css" media="screen" />
<link rel="stylesheet" type="text/css" href="http://localhost:8000/css/flexslider.css" media="screen" />
<link rel="stylesheet" type="text/css" href="http://localhost:8000/js/colorbox/colorbox.css" media="screen" />
<link rel="stylesheet" type="text/css" href="http://localhost:8000/css/carousel.css" media="screen" />
<!-- CSS Part End-->
<!-- JS Part Start-->
<script type="text/javascript" src="http://localhost:8000/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/jquery.nivo.slider.pack.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/jquery.flexslider.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/jquery.easing-1.3.min.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/jquery.jcarousel.min.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/colorbox/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/tabs.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/cloud_zoom.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/jquery.dcjqaccordion.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/custom.js"></script>
<script type="text/javascript" src="http://localhost:8000/js/html5.js"></script>
<!-- JS Part End-->
<!-- Google Fonts (Droid Sans) Start -->
<link href='//fonts.googleapis.com/css?family=Droid+Sans&v1' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=&v1' rel='stylesheet' type='text/css'>
<!-- Google Fonts (Droid Sans) End -->
</head>
<body>
<div class="wrapper-box">
  <div class="main-wrapper">
    <!--Header Part Start-->
    <header id="header" class="style3">
      <div class="htop">
        <div class="links"> 
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/admin')); ?>">Admin</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <!-- <a href="<?php echo e(route('register')); ?>">Register</a> -->
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
      </div>
      <section class="hsecond">
        <div id="logo"><a href="/"><img src="http://localhost:8000/image/logo.png" title="Polishop" alt="Polishop" /></a></div>
<!--         <div id="search">
          <div class="button-search"></div>
          <input type="text" name="search" placeholder="Search" value="" />
        </div> -->
        <div class="clear"></div>
      </section>
<!--Top Menu(Horizontal Categories) Start-->
      <nav id="menu">
        <ul>
          <li class="home"><a title="Home" href="http://localhost:8000/"><span>Home</span></a></li>
          <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="categories_hor">
            <a href="/brand/<?php echo $brand->id; ?>"><?php echo e($brand->brandName); ?></a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </nav>
      <!--Top Menu(Horizontal Categories) End-->
  </header>
    <!--Header Part End-->
    <div id="container">
       <?php echo $__env->yieldContent('content'); ?>
  </div>
  <!--Footer Part Start-->
  <footer id="footer">
    <div class="fpart-inner">
      <div class="social-part">
      
      <div class="clear"></div>
      <div id="powered">
        <!-- Powered by Text Start-->
        <div class="powered_text">
          <p>MobileInfo © VU<br />
          </p>
        </div>
        <!-- Powered by Text End-->
        <div class="clear"></div>
      </div>
      <!-- Back to Top Button Start-->
      <div class="back-to-top" id="back-top"><a title="Back to Top" href="javascript:void(0)" class="backtotop">Top</a></div>
      <!-- Back to Top Button End-->
    </div>
  </footer>
  <!--Footer Part End-->
</div>
</body>
</html>