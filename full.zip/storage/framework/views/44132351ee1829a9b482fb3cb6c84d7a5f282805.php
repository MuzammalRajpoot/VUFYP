

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row justify-content-center">
<form action="<?php echo e(action('MobileController@store')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="mobileName">Name</label>
      <input type="text" class="form-control" required autofocus name="mobileName" placeholder="Mobile Name">
    </div>
     <div class="form-group col-md-6">
      <label for="brandId">Brand</label>
      <select name="brandId" class="form-control" required>
        <option selected>Select</option>
        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brandName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
        <div class="input-group control-group increment mb-2" >
          <input type="file" name="images[]" class="form-control">
          <div class="input-group-btn"> 
            <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
          </div>
        </div>
        <div class="clone hide">
          <div class="control-group input-group mb-2" style="margin-top:10px">
            <input type="file" name="images[]" class="form-control">
            <div class="input-group-btn"> 
              <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
            </div>
          </div>
        </div>
  <div class="form-group">
    <label for="description">Description</label>
    <textarea class="form-control" name="description" rows = "5" cols = "50" name ="description" placeholder="Mobile Description..." required>
    </textarea>
  </div>
  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="price">Price (PKR)</label>
      <input type="number" class="form-control" name="price" placeholder="e.g. 12500" required>
    </div>
    <div class="form-group col-md-2">
      <label for="camera">Camera (MP)</label>
      <input type="number" class="form-control" name="camera" placeholder="e.g. 13" required>
    </div>
      <div class="form-group col-md-2">
      <label for="sim_slots">Sim Slots</label>
      <select name="sim_slots" class="form-control" required>
        <option value="">Select</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="ram">RAM (GB)</label>
      <input type="number" class="form-control" name="ram" placeholder="e.g. 8" required>
    </div>
    <div class="form-group col-md-2">
      <label for="memory">ROM (GB)</label>
      <input type="number" class="form-control" name="memory" placeholder="e.g. 32" required>
    </div>
  </div>
  <input type="submit" class="btn btn-primary" value="Add Mobile" name="submit">
  <?php if($errors->any()): ?>
       <div class="alert alert-danger">
            <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
        </div><br />
  <?php endif; ?>
  <?php if(session()->get('success')): ?>
     <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
      </div><br />
   <?php endif; ?>
</form>
<script type="text/javascript">

    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /var/www/mobile/resources/views/add-mobile.blade.php */ ?>