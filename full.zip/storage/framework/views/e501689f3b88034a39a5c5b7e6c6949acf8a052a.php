<?php $__env->startSection('headers'); ?>
<header id="header" class="style3">
      <div class="htop">
        <div class="links"> 
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/admin')); ?>">Admin</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <!-- <a href="<?php echo e(route('register')); ?>">Register</a> -->
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
      </div>
      <section class="hsecond">
        <div id="logo"><a href="index.html"><img src="image/logo.png" title="Polishop" alt="Polishop" /></a></div>
<!--         <div id="search">
          <div class="button-search"></div>
          <input type="text" name="search" placeholder="Search" value="" />
        </div> -->
        <div class="clear"></div>
      </section>
<!--Top Menu(Horizontal Categories) Start-->
      <nav id="menu">
        <ul>
          <li class="home"><a title="Home" href="<?php echo e(url('/')); ?>"><span>Home</span></a></li>
          <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="categories_hor">
            <a href=""><?php echo e($brand->brandName); ?></a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </nav>
      <!--Top Menu(Horizontal Categories) End-->
  </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\mobileinfo\resources\views/includes/headers.blade.php */ ?>