<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $fillable = [
        'brandName',
    ];

    protected $table = 'brands';

    public function mobile()
	{
        return $this->hasMany('App\Mobile', 'brandId');
	}

}
