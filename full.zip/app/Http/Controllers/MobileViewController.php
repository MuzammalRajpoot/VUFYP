<?php

namespace App\Http\Controllers;

use App\Brand;
use App\Home;
use App\Mobile;
use DB;
use Illuminate\Http\Request;
use Illuminate\Pagination;

class MobileViewController extends Controller
{
    public function index($id)
    {
    $brand = Brand::all();
    $product = Mobile::all()->where('mobileId',$id);
    $latestmobiles = Mobile::latest()->paginate(4);
 	$mobilebrand = Mobile::with('brand')->where('mobileId', $id)->get(); 
// dd($mobilebrand);
       return view('mobile', compact('brand', 'product', 'latestmobiles', 'mobilebrand'));
    }   
}
