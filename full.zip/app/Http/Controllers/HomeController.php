<?php

namespace App\Http\Controllers;
use App\Brand;
use App\Home;
use App\Mobile;
use DB;
use Illuminate\Http\Request;
use Illuminate\Pagination;

class HomeController extends Controller
{
	public function index()
    {
    $brand = Brand::all();
    $product = Mobile::paginate(20);
    $latestmobiles = Mobile::latest()->paginate(4);

       return view('home', compact('brand', 'product', 'latestmobiles'));
    }

    public function OrderA()
    {
        $brand = Brand::all();
        $product = Mobile::orderBy('mobileName', 'desc')->paginate(20);
         $latestmobiles = Mobile::latest()->paginate(4);

        return view('home', compact('brand', 'product', 'latestmobiles'));
    }


}
