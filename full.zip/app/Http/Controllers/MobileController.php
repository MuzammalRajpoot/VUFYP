<?php

namespace App\Http\Controllers;

use App\Mobile;
use App\Brand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades;
use Illuminate\Pagination;

class MobileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mobiles = Mobile::all();
        $brand = Brand::all();
        return view('mobile-index', compact('mobiles', 'brand'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'mobileName' => 'required',
            'brandId' => 'int|exists:brands,id',
            'price' => 'required',
            'camera' => 'required',
            'description' => 'required',
            'ram' => 'required',
            'memory' => 'required',
            'sim_slots' => 'required',
            'images' => 'required',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);

 
        $mobile = new Mobile([
            'mobileName' => $request->get('mobileName'),
            'brandId' => $request->get('brandId'),
            'description' => $request->get('description'),
            'price' => $request->get('price'),
            'camera' => $request->get('camera'),
            'sim_slots' => $request->get('sim_slots'),
            'ram' => $request->get('ram'),
            'memory' => $request->get('memory'),
            'images' => $request->get('images'),
        ]);

        if($request->hasfile('images'))
         {

            foreach($request->file('images') as $image)
            {
                $name=$image->getClientOriginalName();
                $name=explode('.',$name);
                $name=$name[0].time().'.'.$name[1];
                $image->move(public_path().'/images/', $name);
                $data[] = $name;  
            }
         }

         $mobile->images=json_encode($data);

         $arr = array('[', '"', ']');

          $mobile->images=str_replace($arr,'',json_encode($data));
         
  
        $mobile->save();

        return redirect('/admin/mobile')->with('success', 'New Mobile has been Added.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Mobile  $mobile
     * @return \Illuminate\Http\Response
     */
    public function show(Mobile $mobile)
    {
        //
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Mobile  $mobile
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request, $id)
    {

        $mobile = Mobile::Where('mobileId',$id)->first();

        $brands = Brand::all();
        return view('mobile-update', ['mobile' => $mobile, 'brands' => $brands]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Mobile  $mobile
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([

            'mobileName' => 'required',
            'brandId' => 'int|exists:brands,id',
            'price' => 'required',
            'camera' => 'required',
            'description' => 'required',
            'ram' => 'required',
            'memory' => 'required',
            'sim_slots' => 'required',
            'images' => 'required',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);

        $mobile = new Mobile([
            'mobileName' => $request->get('mobileName'),
            'brandId' => $request->get('brandId'),
            'description' => $request->get('description'),
            'price' => $request->get('price'),
            'camera' => $request->get('camera'),
            'sim_slots' => $request->get('sim_slots'),
            'ram' => $request->get('ram'),
            'memory' => $request->get('memory'),
            'images' => $request->get('images'),
        ]);

        if($request->hasfile('images'))
        {

            foreach($request->file('images') as $image)
            {
                $name=$image->getClientOriginalName();
                $name=explode('.',$name);
                $name=$name[0].time().'.'.$name[1];
                $image->move(public_path().'/images/', $name);
                $data[] = $name;
            }
        }

        $mobile->images=json_encode($data);

        $arr = array('[', '"', ']');

        $mobile->images=str_replace($arr,'',json_encode($data));


        Mobile::where('mobileId', $id)
            ->update([
                'mobileName' => $mobile->mobileName,
                'brandId' => $mobile->brandId,
                'description' =>$mobile->description,
                'price' =>$mobile->price,
                'camera' =>$mobile->camera,
                'sim_slots' =>$mobile->sim_slots,
                'ram' =>$mobile->ram,
                'memory' =>$mobile->memory,
                'images' =>$mobile->images,
            ]);
        return redirect('/admin/mobile')->with('success', 'Mobile Information Updated Successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Mobile  $mobile
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $mobile = Mobile::Where('mobileId',$id);

        $mobile->delete();

        return redirect('admin/mobile')->with('success', 'Mobile Phone Deleted');
    }
}
