@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Mobiles</h1>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Price</th>
                <th>Images</th>
                <th>Camera</th>
                <th>Description</th>
                <th>Ram</th>
                <th>Memory</th>
                <th>SIM Slots</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            @foreach($mobiles as $mobile)
                <tr>
                    <td>{{$mobile->mobileId}}</td>
                    <td>{{$mobile->mobileName}}</td>
                    <td>{{$mobile->brandId}}</td>
                    <td>{{$mobile->price}}</td>
                    <td>{{$mobile->images}}</td>
                    <td>{{$mobile->camera}}</td>
                    <td>{{$mobile->description}}</td>
                    <td>{{$mobile->ram}}</td>
                    <td>{{$mobile->memory}}</td>
                    <td>{{$mobile->sim_slots}}</td>
                    <td><a href="/admin/mobile/update/{{$mobile->mobileId}}" class="btn btn-success">Update</a></td>

                    <td>
                        <form action="{{action('MobileController@destroy', $mobile->mobileId)}}" method="post">

                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>

                    </td>

                </tr>

            @endforeach
        </table>
    </div>
@endsection