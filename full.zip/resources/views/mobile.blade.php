@extends('layouts.master')

@section('content')
    <div id="container">
      <!--Left Part-->
      <div id="column-left">
        <!--Bestsellers Part Start-->
        <div class="box">
          <div class="box-heading">Bestsellers</div>
          <div class="box-content">
            <div class="box-product">
              <div class="flexslider">
                <ul class="slides">
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/sony_vaio_1-45x45.jpg" alt="Friendly Jewelry" /></a></div>
                      <div class="name"><a href="product.html">Friendly Jewelry</a></div>
                      <div class="price">$1,177.00</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/apple_cinema_30-45x45.jpg" alt="Apple Cinema 30&quot;" /></a></div>
                      <div class="name"><a href="product.html">Apple Cinema 30&quot;</a></div>
                      <div class="price"><span class="price-old">$119.50</span> <span class="price-new">$107.75</span></div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/ipod_classic_1-45x45.jpg" alt="iPad Classic" /></a></div>
                      <div class="name"><a href="product.html">iPad Classic</a></div>
                      <div class="price">$119.50</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/lotto-sports-shoes-white-45x45.jpg" alt="Lotto Sports Shoes" /></a></div>
                      <div class="name"><a href="product.html">Lotto Sports Shoes</a></div>
                      <div class="price">$589.50</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/Jeep-Casual-Shoes-45x45.jpg" alt="Jeep-Casual-Shoes" /></a></div>
                      <div class="name"><a href="product.html">Jeep-Casual-Shoes</a></div>
                      <div class="price">$131.25</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!--Bestsellers Part End-->
        <!--Latest Product Start-->
        <div class="box">
          <div class="box-heading">Latest</div>
          <div class="box-content">
            <div class="box-product">
              <div class="flexslider">
                <ul class="slides">
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/sony_vaio_1-45x45.jpg" alt="Friendly Jewelry" /></a></div>
                      <div class="name"><a href="product.html">Friendly Jewelry</a></div>
                      <div class="price">$1,177.00</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/apple_cinema_30-45x45.jpg" alt="Apple Cinema 30&quot;" /></a></div>
                      <div class="name"><a href="product.html">Apple Cinema 30&quot;</a></div>
                      <div class="price"><span class="price-old">$119.50</span> <span class="price-new">$107.75</span></div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/ipod_classic_1-45x45.jpg" alt="iPad Classic" /></a></div>
                      <div class="name"><a href="product.html">iPad Classic</a></div>
                      <div class="price">$119.50</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/lotto-sports-shoes-white-45x45.jpg" alt="Lotto Sports Shoes" /></a></div>
                      <div class="name"><a href="product.html">Lotto Sports Shoes</a></div>
                      <div class="price">$589.50</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                  <li>
                    <div class="slide-inner">
                      <div class="image"><a href="product.html"><img src="http://localhost:8000/image/product/Jeep-Casual-Shoes-45x45.jpg" alt="Jeep-Casual-Shoes" /></a></div>
                      <div class="name"><a href="product.html">Jeep-Casual-Shoes</a></div>
                      <div class="price">$131.25</div>
                      <div class="clear"></div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!--Latest Product End-->
      </div>
      <!--Left End-->
      <!--Middle Part Start-->
      <div id="content">
        @foreach ($product as $phone)

        <?php $singleimage=explode(',',$phone->images); ?>
        <div class="breadcrumb"> <a href="index.html">Home</a> &raquo; <a href="#">{{$phone->mobileName}}</a> </div>
        <h1>{{$phone->mobileName}}</h1>
        <div class="product-info">
          <div class="left">
            <?php 
            $imgcount = 0;
            for($i=0;$i<sizeof($singleimage);$i++){ ?>
            
            <?php

              if ($imgcount==0){


              ?>
<div class="image">
           
            <a href="http://localhost:8000/images/{{$singleimage[$i]}}" title="{{$phone->mobileName}}" class="cloud-zoom colorbox" id='zoom1' rel="adjustX: 0, adjustY:0, tint:'#000000',tintOpacity:0.2, zoomWidth:360, position:'inside', showTitle:false"><img width="300" src="http://localhost:8000/images/{{$singleimage[$i]}}" title="{{$phone->mobileName}}" alt="{{$phone->mobileName}}" id="image" /><span id="zoom-image"><i class="zoom_bttn"></i> Zoom</span></a> 
            </div><?php } ?>
            <div class="image-additional"> <a href="http://localhost:8000/images/{{$singleimage[$i]}}" title="{{$phone->mobileName}}" class="cloud-zoom-gallery" rel="useZoom: 'zoom1', smallImage: 'http://localhost:8000/images/{{$singleimage[$i]}}' "><img src="http://localhost:8000/images/{{$singleimage[$i]}}" width="62" title="{{$phone->mobileName}}" alt="{{$phone->mobileName}}" /></a> </div>
          <?php $imgcount++;  } ?>
          </div>
          <div class="right">
            @foreach ($mobilebrand as $bname)
            <div class="description"> <span>Brand:</span> <a href="#">{{$bname->brand->brandName}}</a><br />
              <span>Product Code:</span> Product 3<br />
              <span>Reward Points:</span> 200<br />
              <span>Availability:</span> In Stock</div>
              @endforeach
            <div class="price">Price: <span class="price-old">$119.50</span> <span class="price-new">$96.00</span> <br />
              <span class="price-tax">Ex Tax: $80.00</span><br />
            </div>
<style>
  
  .product-info .image {
     float: none !important; 
    
}
.product-info .image-additional {
    width: 60px;
    margin-left: 0px;
     clear:none; 
    overflow: hidden;
    float: left;
}

</style>
          </div>
        </div>
        <!-- Description and Reviews Tab Start -->
        <div id="tabs" class="htabs"> <a href="#tab-description">Description</a> <a href="#tab-review">Specs</a> </div>
        <div id="tab-description" class="tab-content">
          <p>{{$bname->description}}</p>
        </div>
        <div id="tab-review" class="tab-content">
          <div id="review"></div>
          <h2 id="review-title">Mobile Specifications</h2>
          <br />
          <b>Your Name:</b><br />
          <input type="text" name="name" value="" />
          <br />
          <br />
          <b>Your Review:</b>
          <textarea name="text" cols="40" rows="8" style="width: 98%;"></textarea>
          <span style="font-size: 11px;"><span style="color: #FF0000;">Note:</span> HTML is not translated!</span><br />
          <br />
          <b>Rating:</b> <span>Bad</span>&nbsp;
          <input type="radio" name="rating" value="1" />
          &nbsp;
          <input type="radio" name="rating" value="2" />
          &nbsp;
          <input type="radio" name="rating" value="3" />
          &nbsp;
          <input type="radio" name="rating" value="4" />
          &nbsp;
          <input type="radio" name="rating" value="5" />
          &nbsp;<span>Good</span><br />
          <br />
        </div>
        <script>
  $(document).ready(function(){
  $('#tabs a').tabs();
  });
  </script>
        <!-- Description and Reviews Tab Start -->

        <script type="text/javascript">
(function() {
  // store the slider in a local variable
  var $window = $(window),
      flexslider;
  // tiny helper function to add breakpoints
  function getGridSize() {
    return (window.innerWidth < 320) ? 1 :
		   (window.innerWidth < 600) ? 2 :
		   (window.innerWidth < 800) ? 3 :
           (window.innerWidth < 900) ? 3 : 4;
  }
  $window.load(function() {
    $('#content #related_pro').flexslider({
      animation: "slide",
      animationLoop: false,
	  slideshow: false,
      itemWidth: 210,
      minItems: getGridSize(), // use function to pull in initial value
      maxItems: getGridSize() // use function to pull in initial value
    });
  });
}());
</script>
        <!--Related Product End-->
      </div>
      @endforeach
      <!--Middle Part End-->
      <div class="clear"></div>
    </div>
  </div>
  
@endsection