@extends('layouts.master')

@section('content')

    <div id="column-left">
        <!--Category Start -->
        <script type="text/javascript" src="js/jquery.dcjqaccordion.js"></script>
        <!--Category End -->
        <!--Refine Search Start-->
        <div class="box">
            <div class="box-heading">Refine Search</div>
            <div class="box-content">
                <ul class="box-filter">
                    <li><span id="filter-group">Price</span>
                        <ul>
                            <li>
                                <a href="#">
                                    <label for="filter3">$0 - $100 (1)</label>
                                </a>
                            </li>
                            <li>
                                <label for="filter4">$100 - $500 (5)</label>
                            </li>
                            <li>
                                <label for="filter5">$500 - $1000 (1)</label>
                            </li>
                            <li>
                                <label for="filter6">$1000 - $1500 (0)</label>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <!--Refine Search End-->
        <!--Latest Product Start-->
        <div class="box">
            <div class="box-heading">Latest</div>
            <div class="box-content">
                <div class="box-product">
                    <div class="flexslider">
                        @foreach ($mobiles as $mobile)
                            <ul class="slides">
                                <li>
                                    <?php $singleimage=explode(',',$mobile->images); ?>
                                    <div class="slide-inner">
                                        <div class="image" style="width:90px;"><a href="http://localhost:8000/mobile/{{$mobile->mobileId}}"><img src="http://localhost:8000/images/{{$singleimage[0]}}" alt="{{$mobile->mobileName}}" /></a></div>
                                        <div class="name"><a href="http://localhost:8000/mobile/{{$mobile->mobileId}}">{{$mobile->mobileName}}</a></div>
                                        <div class="price">{{$mobile->price}} Rs.</div>
                                        <div class="clear"></div>
                                    </div>
                                </li>
                            </ul>
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
        <!--Latest Product End-->
    </div>
    <!--Middle Part Start-->
    <div id="content">
        <!--Breadcrumb Part Start-->
        <div class="breadcrumb"> <a href="/">Home</a></div>
        <!--Breadcrumb Part End-->
        <h1>MobileInfo - VU FYP</h1>
        <div class="product-filter">
            <div class="sort"><b>Sort By:</b>
                <select>
                    <option value="" selected="selected">Default</option>
                    <option value="">Name (A - Z)</option>
                    <option value="">Name (Z - A)</option>
                    <option value="">Price (Low &gt; High)</option>
                    <option value="">Price (High &gt; Low)</option>
                </select>
            </div>
        </div>

        <!--Product Grid Start-->
        <div class="product-grid">

            @if(count($mobiles) <= 0)
                <p></p>
             <h1>No Results Founds</h1>
            @endif

            @foreach ($mobiles as $mobile)

                <?php $singleimage=explode(',',$mobile->images); ?>
                <div>
                    <div class="image thumbnail"><a href="http://localhost:8000/mobile/{{$mobile->mobileId}}"><img width="200" height="200" src="http://localhost:8000/images/{{$singleimage[0]}}" title="{{$mobile->mobileName}}" alt="{{$mobile->mobileName}}" /></a></div>
                    <div class="name"><a href="http://localhost:8000/mobile/{{$mobile->mobileId}}">{{$mobile->mobileName}}</a></div>
                    <div class="price"> <span class="price-new">{{$mobile->price}} Rs.</span> <br />
                    </div>
                </div>

        @endforeach
        <!--Product Grid End-->
            <div class="clear"></div>
            <!--Pagination Part Start-->

            <!--Pagination Part End-->
            <style>

                ul.pagination {
                    list-style: none;
                    display: inline;
                    letter-spacing: 9px;
                    font-size: 24px;
                }
                li.page-item {
                    float: left;
                    font-size: 24px;
                }
                li.page-item a{
                    float: left;
                    font-size: 24px !important;
                }


            </style>
        </div>
        <!--Middle Part End-->
        <div class="clear"></div>
    </div>
@endsection
