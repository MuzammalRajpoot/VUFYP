<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMobilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mobiles', function (Blueprint $table) {
            $table->increments('mobileId');
            $table->string('mobileName');
            $table->integer('brandId')->unsigned();
            $table->foreign('brandId')->references('brandId')->on('brands');
            $table->double('price');
            $table->float('camera');
            $table->text('description');
            $table->integer('ram');
            $table->integer('memory');
            $table->smallInteger('sim_slots');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mobiles');
    }
}
