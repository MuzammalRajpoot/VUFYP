<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');



Route::get('/mobile/{id}', 'MobileViewController@index');

Route::get('/brand/{name}', 'BrandController@show');

Route::post('/brand/filter','BrandController@filter')->name('brand/filter');



Auth::routes();

Route::get('/admin', 'AdminController@index')->name('admin')->middleware('auth');

Route::get('/brands', 'BrandController@index')->name('brands')->middleware('auth');
Route::post('/brands', 'BrandController@store')->name('brands')->middleware('auth');
Route::resource('/brands', 'BrandController')->middleware('auth');
Route::get('/brands/update/{id}', 'BrandController@edit')->middleware('auth');
Route::post('/brands/edit/{id}', 'BrandController@update')->middleware('auth');


Route::resource('/admin/mobile', 'MobileController')->middleware('auth');

Route::get('/admin/mobile/create', 'MobileController@store')->middleware('auth');

Route::get('/admin/mobile/update/{id}', 'MobileController@edit')->middleware('auth');

Route::get('/admin/mobile/delete/{id}', 'MobileController@delete')->middleware('auth');

Route::post('/admin/mobile/edit/{id}', 'MobileController@update')->middleware('auth');
